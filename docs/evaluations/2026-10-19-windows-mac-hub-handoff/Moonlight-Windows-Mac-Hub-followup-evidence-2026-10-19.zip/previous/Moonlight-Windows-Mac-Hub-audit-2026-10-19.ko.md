# Moonlight Windows↔Mac/Hub 독립 클라우드 검증

검증일: 2026-10-19 UTC. 저장소: `Muuuuoouuun/moonlight_pro`.

**기존 후보를 보존한 채 무결성·최신 refs·전체 시험·웹 빌드 검증을 마쳤다. Windows↔Mac 실기 연동 완료 판정은 할 수 없다.** 새 경합·복구 문제를 발견했으며, 최소 수정 3개를 별도 패치로 제공한다. JavaScript 패치 2개는 실행 회귀를 통과했고, Swift 패치 1개는 컴파일러 부재로 소스 검토와 적용 검사까지만 완료했다. 409 이후 입력 잠금, 초기화 대기 취소, 긴 회의 복원, Mac 세션 일관성 문제는 남아 있다.

원격 Git 쓰기·PR 변경·main 병합·배포·실사용 DB/Hub/모델 접근·보안 설정 변경·사용자 기존 파일 삭제는 하지 않았다. 예약 100건 경계는 별도 담당 범위로 제외했다. 과거 Mac SwiftPM 및 브라우저 거부 작업은 재시도하거나 우회하지 않았다.

## 1. 후보 회수 및 최신 refs

입력 Library: `libfile_99a65bb41c748191b85750da0e072fc1`, `Moonlight-R8-local-integration-2026-10-19-67eb1d9b.zip`.

- ZIP SHA256: `10067542a9b7313039e081001778daa3848f34012bc1cc7b395a00ef6c9e587d`.
- 압축 경로의 절대경로·상위탈출·symlink를 배제하고 CRC 확인 후 격리 디렉터리에 회수했다.
- `FILE-SHA256.tsv` 419개 및 `candidate-final/manifest.json` 5개 항목의 바이트 수·SHA256 모두 일치했다.
- 증분 bundle prerequisite는 아래 main이며, `git bundle verify`와 `git fsck --full`을 통과했다.
- 회수 patch는 `git diff --abbrev=8 main candidate`와 717,483 bytes 및 SHA256 `22663d9682d5f28e5c914db239769c60fefcd4e1146bcf18c08a2fae8c6bcce9`가 완전히 같다.
- 별도 baseline 복제본에 patch를 적용한 tree `9ba87b276f865f97d014a83828a7e218b7c6fb83`가 후보 tree와 일치했다.

최종 GitHub 읽기 조회: **2026-10-19 11:50:28 UTC**, 최초 조회와 변동 없음.

| 대상 | 확인 SHA / 상태 |
|---|---|
| main | `94a71abd78b958a137746f5ab90fc6791d0b2c58` |
| Windows PR #38 | `dbd357b3508ff8252c83490653c8c7ab4a909bf1`, open / draft / 미병합 |
| codex/office-connection-20261002 | `12103a76eadef632a57f0da151487d8076fcecdd` |
| Library 통합 후보 | `67eb1d9b316843f5acd70de513d5a7b8d823bfdc` |

후보는 main/PR38/Office의 후손이며 각각 48/47/41개 커밋 앞선다. Office는 PR38을 포함하고 6개 커밋 앞선다. 후보의 `apps/desktop` tree는 최신 Office와 완전히 같다(`e5e15a64cdf663e9756ac8c99b8b2921dcc180d3`). 따라서 이번 Desktop 결함은 최신 Office에도 남아 있다. PR38 이후 세션 전환 가드·빌드 식별·Windows 전용 Office 패널·패키지 검증·Windows 경로 보정은 후보에 포함된다.

## 2. 이번 세션에서 실행한 검증

환경은 Linux x64, Node `v24.19.0`, npm `11.9.0`이다. 원본 후보와 시험용·수정용 checkout은 별도의 로컬 clone이다. 실제 앱 환경변수와 `.env`는 복사하지 않았다. 테스트는 주입 함수, 임시 파일, loopback/UNIX socket만 사용하며 운영 데이터와 분리했다.

초기 사전 설치 의존성에 Next `16.3.5`가 있어 그 결과를 보조 기록으로 남겼다. 별도 `locked-validation`에서 `npm ci --ignore-scripts --no-audit --no-fund`를 성공시킨 뒤 Next **16.3.8** 등 lockfile 버전으로 전체 시험·Hub/Engine 빌드·typecheck를 다시 실행했다. 아래 핵심 판정은 이 재실행 결과다. `--ignore-scripts`는 네이티브 실행파일 설치·빌드를 했다는 뜻이 아니다.

| 범위 | 실제 결과 | 증거 |
|---|---:|---|
| 원본 후보 전체 `npm test` | **5613 total / 5576 pass / 3 fail / 34 skip** | `evidence/locked-root-suite.log` |
| main에서 실패 파일 2개 재실행 | 17 total / 14 pass / **동일 3 fail** | `evidence/baseline-failures.log` |
| 원본 Desktop 전체 | **372 pass / 0 fail / 3 skip** | `evidence/locked-desktop-suite.log` |
| Hub + Engine webpack 빌드 | 각각 exit 0 | `evidence/locked-{hub,engine}-build.log` |
| 설정된 workspace typecheck | exit 0 | `evidence/locked-typecheck.log` |
| 호스트 등록·launcher·env 격리 시험 | 25 pass / 0 fail | `evidence/host-registration-tests.log` |
| 별도 패치 3개 동시 적용 검사 | 충돌 없이 적용 / `git diff --check` 통과 | `evidence/patch-application-and-preservation.json` |
| 패치 적용본 Desktop 전체 | **376 pass / 0 fail / 3 skip** | `evidence/patched-desktop-suite.log` |
| 패치 적용본 Office+native wiring 선택 | 192 total / **190 pass / 0 fail / 2 skip** | `evidence/patched-hub-contracts-final.log` |
| 패치 적용본 Hub webpack 빌드 | exit 0 | `evidence/patched-hub-build.log` |
| 패치 적용본 소스 syntax guard | 1777파일 / 0 issues | `evidence/patched-lint.log` |

서로 겹치는 선택 시험 수는 합산하지 않는다. syntax guard는 의미·스타일 분석이 아니다. 3개 전체 시험 실패는 `packages/codex-worker/config.test.mjs` 2건과 `scripts/office-codex-provider.test.mjs`의 종료 프로세스 그룹 검사 1건이다. main에서도 같은 실패를 재현했고 해당 시험·구현 파일이 후보와 같음을 확인했다. 기존 실패라는 뜻이지 통과로 처리한다는 뜻은 아니다. skip에는 DB 조건 및 네이티브 실행 조건 미충족이 포함된다.

## 3. 별도 수정 후보

세 패치는 모두 정확한 `67eb1d9b`에 적용 가능하다. 원본 후보와 원본 Library 파일은 변경하지 않았다. 별도 수정 checkout에서만 함께 적용해 시험했고 신규 후보 커밋·원격 브랜치·PR은 만들지 않았다. 작성자 외 독립 소스 검토도 완료했다.

| 패치 | 문제와 수정 | 검증 수준 |
|---|---|---|
| `desktop-generation-guard.patch` | `chatSend`·`tick`가 초기화를 기다리는 동안 origin/세션이 교체되면 이전 질문이 새 Hub로 전송될 수 있었다. await 직후 연결 객체를 다시 검사하는 제품 코드 2줄을 추가했다. | 신규 4개 회귀 **4 fail→4 pass**; 관련76 pass; 전체 Desktop376 pass/3skip |
| `hub-contract-retry-candidate.patch` | 받은 4xx 또는 버전·담당·문맥·답변 계약 거부 후 생성 POST를 한 번 더 보냈다. 응답 수신 후 확정 거절은 재시도하지 않도록 제한했다. | 신규 시험 **2 fail→0 fail**; 관련18 pass; 확장216 pass/2skip; 독립 적용본 선택190 pass/2skip |
| `native-preflight-generation.patch` | Mac의 공유 세션 조회 중 disconnect/clearSession이 발생해도 await 뒤 구 쿠키 설치·POST 전송으로 이어질 수 있었다. 두 preflight await 뒤 세대와 Task 취소를 전송 전에 확인한다. | 소스 제어흐름 확정·적용/공백 검사·기존 Node wiring4 pass. **새 Swift 2개 시험의 12조합은 미실행** |

Hub 패치는 legacy 502/503·전송 예외의 제한된 재시도를 유지한다. 따라서 모든 모델 생성의 exactly-once를 보증하지 않는다. Swift 패치의 컴파일 및 변경 전 실패/변경 후 성공은 macOS에서 검증해야 한다. patch와 테스트 SHA256은 `PATCHES.md` 및 묶음 manifest에 있다.

## 4. 남은 문제와 권장 후속 순서

| 우선순위 | 발견·재현 및 한계 | 상태 |
|---|---|---|
| 높음 | **Office 409 뒤 입력 잠금**: 서버는 revision 불일치 시 turn을 만들기 전에 거절한다. renderer는 matching turn이 생겨야 pending을 지워서 정상 GET 새로고침 후에도 입력이 잠긴다. 실제 renderer를 VM/최소 DOM에 올려 재현했다. | 미수정. 확정 미수락과 결과 불명을 구별하는 복구 필요. 모든 실패의 pending을 지우면 중복 위험 |
| 높음 | **준비 대기 취소 무효**: 초기 로컬 상태 읽기 중 “기다림 중단”을 눌러도 `chatCancel`은 false이고, 준비가 끝나면 POST 1회가 실행된다. 수정된 세대 가드도 같은 연결의 취소는 해결하지 않는다. | 미수정. 전송 전 대기 단계도 취소 ticket에 포함 필요 |
| 중간 | **긴 회의 복원 불일치**: 유효한 한글 입력1000자·답변10000자의 7turn 233,947bytes는 통과하지만 8turn 267,322bytes는 Hub200/ready→Desktop invalid-response. Desktop 전체 응답 상한262,144bytes와 서버 무제한 turn 집계가 충돌한다. | 미수정. 공통 페이지네이션/본문 투영 계약 필요. 제한만 올리지 않음 |
| 중간 | **Mac 로그아웃 snapshot 모순**: 지연 cookies.get 뒤 로그아웃이 겹치면 이전 유효 session+signedOut:true가 함께 반환된다. JS UNIX 계약으로 재현했고 Swift는 session을 먼저 처리하는 소스 분기다. | 미수정. 실제 Mac 영향 미실행; 세대 패치로 같은 세대의 snapshot 모순은 해결되지 않음 |
| 중간 | **로그아웃 의도 유실**: JS Set의 signedOut 기록이 shell 재시작 후 사라진다. native가 로그아웃을 못 봤고 Keychain 자격이 남았다면 자동 재로그인 조건이 열린다. | JS 상태 유실 재현/Swift 조건부 영향. 실제 재로그인 미검증; 정책·지속 상태 설계 필요 |
| 낮음·조건부 | **descriptor 교체/종료 경합**: A의 descriptor 읽기와 삭제 사이 B가 게시하면 B의 파일이 사라질 수 있다. 겹친 lifecycle 주입으로 재현했다. | 정상 앱 single-instance lock이 이 순서를 막는지 미확인. 일반 재시작 실패로 단정 안 함 |

추가 계약 공백: 영구 `running/unknown` 회의의 cancel/recover API가 없고, UI 취소가 이미 시작한 Engine 모델 호출을 중단한다는 보장은 없다. Native 회의 목록은 첫 20개만 디코드하고 nextCursor를 노출하지 않는다. Office 9개 모듈의 runtime export106개 선언 누락은0, Bundler strict 오류0이나 NodeNext strict에는 기존 상대 import 확장자 오류5건이 있다. 현재 웹 빌드 실패와 구분한다.

## 5. 호스트 등록·버전·실기 경계

- 호스트 등록은 MCP client 설정과 Desktop의 Hub session attach를 구별했다. 임시 home/config로 등록·launcher25건이 통과했지만 실제 호스트 설정을 조회·수정하거나 서비스를 등록하지 않았다. `clientTargets`는 Claude Desktop·VS Code에 macOS Library 경로를 고정하고 플랫폼 인자를 받지 않는다. Windows 자동 등록 성공은 입증되지 않았다.
- Desktop은 HTTP200의 error 봉투를 실패로 처리하고, timeout/offline/auth/conflict/invalid를 구별한다. 실패를 빈 성공으로 바꾸지 않는 관련 시험이 통과했다. read 이후 write reservation·요청 ID·origin 분리·늦은 응답 폐기 계약도 점검했다.
- chat `2026-09-22.v3`, workflow receipt `2026-09-21.v1`, commander bound source `2026-10-02.bound-source.v1`는 정확 버전 비교다. 모르는 버전은 실패하며 협상 프로토콜은 없다. 설치된 구버전 앱/운영 서버 조합의 실제 호환을 인증한 것이 아니다.
- Windows hotkey, 로그인 UI, Acrylic/DWM, 실제 Electron cookie 이벤트, 설치/업데이트, 멀티모니터, Mac Swift/Keychain/Metal/native, 실사용 Hub·DB·모델 왕복은 **미검증**이다. Windows/Mac 패키징과 full SwiftPM도 실행하지 않았다. Linux 웹 빌드·Node 시험을 해당 성공으로 표현하면 안 된다.
- 이번 세션의 자동 승인 거부 또는 불확실한 원격 쓰기 결과는 없다. 현재 미완료 항목은 네이티브 환경 부재·범위 제한·남은 제품 계약 문제다. 과거 거부는 그대로 존중했다.

## 6. 전달 자료

동반 ZIP에는 원본 후보를 수정하지 않고 재사용할 수 있도록 다음을 넣었다.

- 이 한국어 종합 보고서와 `REPRODUCE.md`, `PATCHES.md`.
- `patches/`의 독립 패치3개(회귀 테스트 포함).
- `evidence/`의 새 실행 로그·회귀 red/green·재현 스크립트·각 담당 상세 한국어 보고서·독립 검토.
- `remote/`의 최초/최종 refs 및 로컬 ancestry·patch/tree 무결성 증거.
- 모든 전달 파일의 `FILE-SHA256.tsv`. 원본 bundle은 재포장하지 않았으며 입력 Library identity와 해시는 위에 보존했다.

실기 재검증은 먼저 JavaScript 패치의 제품 동작과 미해결 409/취소 복구를 정리한 뒤 Windows·Mac 각각에서 수행해야 한다. Swift 후보는 native 회귀와 컴파일을 통과하기 전 실행 검증 완료로 취급하지 않는다.

## 7. 전달 상태와 차단 사유

보고서·테스트·패치 ZIP은 로컬에서 완성했고 압축 CRC와 모든 포함 파일 SHA256을 검증했다. Library의 필수 prepared-upload helper는 인증된 도구 목록 조회 단계에서 `HTTP 401`로 실패했다. 대상은 이 보고서와 `Moonlight-Windows-Mac-Hub-evidence-2026-10-19.zip`의 신규 저장이다. 업로드 세션 생성·바이트 전송·최종 저장 전 실패이므로 **Library에는 저장되지 않았다**. 기존 입력 Library 파일은 변경되지 않았다. 이 실패는 자동 승인 심사의 거절이나 불확실한 원격 쓰기가 아니라 helper 인증 실패다. 별도 인증 경로/직접 쓰기로 우회하지 않았다. 인증이 복구된 세션에서 두 완성 파일의 Library 저장이 남아 있다.
