# 후속 JS 세션 응답 일관성 수정 후보

결론: **Linux에서 원본의 모순 응답과 순서 역전을 실행 재현했고 JS 수정 뒤 회귀 8개가 통과했다.** 범위는 Mac companion용 JS Unix socket bridge의 snapshot 일관성이다. 실제 Mac 로그인/Keychain/Swift/Windows native 검증이나 로그아웃 상태의 영속화 수정으로 확대해서 해석하면 안 된다.

기준 SHA는 `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`. 작성 위치 `/workspace/moonlight-audit/session-followup`은 원본 candidate의 `--no-hardlinks` 독립 clone이다. 후보 원본, 이전 세 패치 및 이전 수정 복제본은 보존했다.

## 확인한 결함과 변경

원본 `apps/desktop/hub-session-bridge.js`는 `cookies.get()` 결과를 기다린 뒤 현재 `signedOutOrigins`를 읽어 같은 응답에 조합했다. 조회가 이전 쿠키 snapshot을 반환하는 사이 명시 로그아웃 event가 발생하면 `{session: 이전유효쿠키, signedOut:true}`가 실제로 반환됐다. 로그아웃 직후 재로그인까지 진행되면 signedOut은 false로 돌아왔지만 이전 cookie가 반환됐다. Swift 소비자는 유효 session 분기를 signedOut보다 먼저 처리하므로 첫 모순도 무해하다고 볼 수 없다. 이번 작업에서 Swift를 실행하지는 않았다.

변경은 메모리 안의 origin별 cookie revision과 진행 중인 쓰기 수만 추가한다.

- 기존 유효 bridge write 시작·종료(성공/실패 모두)와 해당 origin 세션 cookie 변경 event에서 revision을 증가시킨다.
- 조회 후 이미 명시 로그아웃으로 표시되어 있으면 session을 null로 응답한다.
- 진행 중인 쓰기는 origin별 개수로 추적한다. 로그아웃으로 확정된 상태가 아니고 아직 cookie write가 진행 중이면 기존 rejected 봉투를 사용한다. 조회 대기 전후 모두 검사하며 겹친 쓰기 하나가 끝나도 다른 쓰기의 예약을 해제하지 않는다.
- 조회 중 revision이 바뀌었고 현재 로그아웃 표시가 없으면 한 번만 다시 조회한다. 두 번 모두 변경되면 기존 `{error:'rejected'}` 봉투를 사용한다.
- 자연 만료는 기존대로 명시 로그아웃 표시를 만들지 않는다. 새 로그인은 기존대로 로그아웃 표시를 해제한다.

새 영속 파일·DB·인증 방식·원격 보안 설정·자격 증명 저장 정책은 추가하거나 변경하지 않았다. 기존 `expired-overwrite`의 로그아웃 분류도 유지했다. API envelope 필드는 바뀌지 않았다. 재조회는 cookie read만 수행하며 write를 재실행하지 않는다.

## 실행 결과

| 확인 | 원본/수정 결과 |
|---|---|
| 새 Linux JS 회귀 | 원본 **1 pass / 7 fail**, 수정 **8 pass / 0 fail** |
| 기존 bridge 시험과 함께 | 수정 **8 pass / 0 fail / 3 skip** — 3개는 macOS/Swift 전용 기존 시험 |
| 전체 Desktop suite | 수정 **380 pass / 0 fail / 3 skip**, 총 383 tests |
| 문법/공백 | `node --check` 두 변경 파일, `git diff --check` 통과 |
| 적용 확인 | 원본 직접 `git apply --check` 통과; 이전 세 패치 다음에 적용 검사·실제 적용·공백 검사도 독립 clone에서 통과 |

새 회귀 8개는 실제 로컬 Unix socket과 주입한 메모리 cookie double을 사용한다. 외부 Hub·운영 DB·모델 API는 호출하지 않았다.

1. cookie 조회 중 명시 로그아웃 → 이전 쿠키 제거, `session:null/signedOut:true`; 이후 명시 로그인은 새 세션으로 회복.
2. 조회 중 로그아웃→재로그인 → 1회 재조회하여 새 쿠키 반환; 이전 쿠키 반환 금지.
3. 자연 만료 → `session:null/signedOut:false`, 명시 로그아웃을 지어내지 않음.
4. 연속 cookie 변경 → 조회 최대 2회 후 기존 rejected 봉투; 다음 안정 조회에서 회복.
5. cookie event가 없는 double에서 다른 bridge write가 먼저 완료 → 이전 snapshot 폐기 후 새 cookie 확인.
6. 다른 cookie 이름/다른 domain 변경 → 영향 없는 조회를 불필요하게 재실행하지 않음.
7. cookie set가 대기하는 동안: 그 전에 시작한 조회와 그동안 새로 시작한 조회 모두 rejected, set 완료 뒤 정상 회복.
8. 겹친 쓰기 중 하나가 먼저 끝나도 나머지 진행 중 쓰기의 예약 유지; 마지막 쓰기가 실패해도 예약 정리 후 실제 cookie 상태를 다시 읽음.

증거: `baseline-regression.tap`, `after-regression.tap`, `desktop-suite.tap`. 전체 Desktop 결과는 **새 JS snapshot 패치만 기준 SHA에 적용한 checkout**의 결과이며 이전 세 패치까지 합친 통합 결과가 아니다. 부모 작업이 별도 통합 검증을 수행한다.

## 산출물·적용 순서

`session-snapshot-consistency.patch`의 변경 경로는 다음 두 개뿐이다.

- `apps/desktop/hub-session-bridge.js` — +43 / -16
- `apps/desktop/hub-session-snapshot.test.js` — 신규 184행

패치는 기준 SHA에 바로 적용 가능하며, 기존 세 패치와 경로가 겹치지 않는다. 다음 순서를 별도 `/workspace/moonlight-audit/session-followup-apply-final` clone에서 확인했다.

1. 기준 `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`
2. `../desktop/desktop-generation-guard.patch`
3. `../hub/hub-contract-retry-candidate.patch`
4. `../host/native-preflight-generation.patch`
5. `session-snapshot-consistency.patch`

`manifest.json`은 패치·로그·보고서 SHA-256, 정확한 변경 경로 및 검증 범위를 기록한다. 이는 검토용 별도 패치이며 commit·원격쓰기·PR·main 병합·배포를 수행하지 않았다.

독립 소스 검토 담당은 held cookie set 구간을 추가로 지적했고, 위 쓰기 개수 추적과 회귀 2개로 보완한 최종 패치 `f1464d693def09901a94594aa867c1d87bd30c6ded170b3d0825a4638d9960c8`를 검토해 추가 blocker가 없다고 확인했다. 초기 `0056f2d…` 패치는 최종 산출물이 아니다.

## 남은 제한

shell 재시작 뒤 explicit logout 기억이 사라지는 기존 문제는 수정하지 않았다. 지속 logout tombstone은 정책·영속화 설계가 필요하므로 이번 소규모 응답 일관성 수정에서 제외했다. 실제 Electron cookie event 전달 시점, Mac Keychain/Swift 동작, 실제 Windows/Mac 연동은 이번 Linux 결과로 판정하지 않는다. Swift compiler 우회, 이전 denied 작업 재시도, Claude API 호출은 없었다.
