# D3: 준비 중 Council 요청 취소 후보

기준 후보 `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`에 기존 `desktop-generation-guard.patch`를 적용한 별도 clone `/workspace/moonlight-audit/desktop-cancel-followup`에서 작업했다. 원본 후보·기존 패치·기존 보고서/재현 증거는 보존했다.

## 수정 결과

이전에는 `chatSend()`가 연결 준비(`current.ready`)를 기다리는 동안 `chat.cancel()`에 실행 중 요청이 등록되지 않았다. 따라서 UI에서 기다림을 중단해도 `cancelled:false`가 반환되고, 준비가 끝나면 원래 질문이 POST로 전송됐다.

`apps/desktop/pet/main/pet-hub.js`의 요청 식별자는 준비 단계부터 최종 응답까지 한 번에 하나의 전송을 점유한다. 취소는 점유를 즉시 무효화하고 실제 진행 중 요청의 `chat.cancel()`도 항상 실행한다. 이후 명시적 새 전송은 허용한다. 이전 요청은 자기 식별자가 여전히 현재 요청인 경우에만 연결 상태 갱신 및 점유 정리를 할 수 있다.

연결 변경·세션 교체·dispose도 점유를 무효화한다. 기존 연결 세대 검사를 먼저 유지하므로 연결 변경의 `stale-origin`과 같은 연결에서 취소의 `cancelled` 봉투를 구별한다. 같은 origin을 유지하는 설정 확인은 기존 요청을 취소하지 않는다.

제품 변경은 pet-hub.js 한 파일이며 신규 회귀 파일 `pet-hub-cancellation.test.js`에 8개 검사를 추가했다. 반환 봉투·API 요청 계약·서버 API·DB·보안 설정은 변경하지 않았다.

## 실행 증거

작업 디렉터리 `/workspace/moonlight-audit/desktop-cancel-followup`에서 실행했다.

```sh
node --test apps/desktop/pet/main/pet-hub-cancellation.test.js
node --test apps/desktop/pet/main/pet-hub-cancellation.test.js apps/desktop/pet/main/pet-hub-generation.test.js apps/desktop/pet/main/pet-chat.test.js apps/desktop/pet/main/pet-hub.test.js
npm --workspace @com-moon/desktop test
node --check apps/desktop/pet/main/pet-hub.js
node --check apps/desktop/pet/main/pet-hub-cancellation.test.js
git diff --check
```

- 변경 전 실제 제품 코드를 import한 신규 8검사: **4 pass / 4 fail**, exit 1 (`before.tap`, `before-status.json`). 첫 재현의 실제 결과는 `cancelled:false`, POST 1회였다.
- 변경 후 관련 4파일: **61 pass / 0 fail / 0 skip**, exit 0 (`after-targeted.tap`). 신규 8검사 전부 통과.
- 변경 후 데스크톱 전체: **387 tests, 384 pass / 0 fail / 3 skip**, exit 0 (`after-desktop.tap`).
- 문법 검사 및 `git diff --check` 통과.
- D3 delta를 별도 baseline 파일 트리에 `git apply --check --whitespace=error-all` 후 적용했고, 결과 두 파일이 검사한 소스와 바이트 단위로 일치함을 확인 (`apply-validation.log`).
- 독립 읽기 전용 검토에서도 identity 정리, 취소 시 실제 abort 호출, 같은 origin 유지 분기, 연결 변경/dispose 무효화에서 차단할 결함을 찾지 못했다.

신규 검사는 준비 중 취소 후 POST 0회, 반복 취소의 멱등성, 준비 완료 전 명시적 재전송, 준비/전송 단계 중복 차단, 이전 요청 완료 뒤 새 요청 상태 보존, origin·세션 교체, dispose, 기존 진행 중 abort와 늦은 응답 폐기를 확인한다. 외부 네트워크는 사용하지 않았고 fetch 대역 및 기존 시험의 로컬 HTTP만 사용했다.

## 패치와 의존성

적용 순서는 다음과 같다.

1. 기준 SHA `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`.
2. 기존 `evidence/desktop/desktop-generation-guard.patch` — SHA256 `250da48139a7b1c4983766ed24bd7e1cfbbf3bc33b8d991d681d04b87ed4afcb`.
3. 이번 `desktop-queued-cancellation.patch` — SHA256 `a466754719e967b0386fe9f3e99a37471dbe4088275d649c1ac9b117d98caa7d`.

이번 패치는 위 2번이 적용된 pet-hub.js를 기준으로 만든 **D3 delta**다. 기존 generation 회귀 파일이나 tick 변경을 중복 포함하지 않는다. `manifest.json`에 baseline/result 소스와 배포용 증거의 SHA256을 기록했다. 어떤 원격 커밋·PR·병합·배포도 하지 않았다.

## 한계

취소는 아직 시작하지 않은 로컬 요청을 막고 진행 중 클라이언트 기다림/응답 반영을 취소한다. 이미 서버가 처리한 모델 호출·업무 기록까지 되돌리거나 중단했다고 주장하지 않는다.

준비 중 점유는 기존 `chatSession().busy/busyWith` 반환값에는 표시하지 않는다. 패널을 다시 열 때 준비 중 잠금 표시가 없을 수 있지만, 백엔드 전송 진입점은 중복을 `busy`로 거절한다. 준비 I/O가 완료되지 않으면 취소된 예전 chatSend Promise도 그 완료까지 남지만, 취소는 즉시 적용되고 새 요청을 차단하지 않는다. UI는 기존 gate로 취소된 응답을 무시한다.

Linux Node 계약 검사 결과다. Windows 실기 hotkey/login/Acrylic 및 macOS 네이티브 로그인·UI 성공은 검증하지 않았다. 추가 승인이나 도구 차단은 없으며, 실기 검증이 남아 있다.
