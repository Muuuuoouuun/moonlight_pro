# Desktop 후속 안전 수정 전달

이전 감사의 D2(Office 409 뒤 입력 잠금)와 D3(초기화 중 취소 무효)를 서로 독립적인 추가 패치로 수정했다. 원래 후보 `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`, 기존 패치와 보고서는 보존했다. 원격쓰기·운영 DB·보안 설정 변경·배포·Claude API·native/compiler 우회는 하지 않았다.

| 패치 | SHA256 | 기준/의존성 |
|---|---|---|
| `office/office-definitive-rejection.patch` | `c871bb9381e8ce56d22bd5bcb461dbd6d88680c1263b1991e69bb026236307a8` | 후보67. 기존 generation과 수정파일 비중복. 시험에는 generation 포함 |
| `cancellation/desktop-queued-cancellation.patch` | `a466754719e967b0386fe9f3e99a37471dbe4088275d649c1ac9b117d98caa7d` | 후보67 + 기존 generation patch 필수 |

권장 적용 순서는 후보 → 기존 `desktop-generation-guard.patch`(SHA256 `250da48139a7b1c4983766ed24bd7e1cfbbf3bc33b8d991d681d04b87ed4afcb`) → D2 → D3다. D2/D3는 서로 파일이 겹치지 않는다. 기존 generation의 변경을 이번 패치에 중복 포함하지 않았다.

D2는 정확한 Office turn POST의 두 preclaim 오류(revision-changed/closed), HTTP409, conflict, persisted:false, receipt 없는 엄격한 봉투만 해제한다. 입력을 보존하고 조회 후 명시적 새 전송만 허용한다. generic409/request-ID reuse/unknown/timeout/응답유실은 기존 보류를 유지한다. 세부 근거·실행 명령은 `office/office-followup.ko.md`를 따른다.

D3는 준비 단계부터 단일 요청 token을 점유하고 취소·세션교체·dispose 시 이를 무효화한다. 준비 중 취소의 POST는 0회이고, 명시적 새 send와 기존 active abort를 유지한다. 이전 요청의 finally/늦은 응답이 새 요청 상태를 해제하지 못한다. 세부 근거는 `cancellation/cancellation-followup.ko.md`를 따른다.

| 검증 | 결과 |
|---|---|
| D2 최종 신규13검사, 수정 전 | 10 pass / 3 fail |
| D2 수정 후 관련4파일 | 49 pass / 0 fail |
| D3 신규8검사, 수정 전 | 4 pass / 4 fail |
| D3 수정 후 관련4파일 | 61 pass / 0 fail |
| D3+기존generation Desktop 전체(D2 미포함) | 384 pass / 0 fail / 3 skip |

두 delta 모두 독립 검토에서 새 blocker가 없었다. 부모가 전체 결합 패치에 대해 수행하는 최종 집계는 별도 결과를 따른다.

한계: D2는 모든 미확인 pending을 해제하는 수정이 아니다. D3도 이미 서버가 처리한 작업을 취소하거나 되돌리지 않으며, 준비중 점유는 기존 `chatSession().busy` UI 값에 추가 표시하지 않는다. 이전 취소 Promise는 준비 I/O가 끝날 때까지 남을 수 있지만 POST를 시작하거나 새 요청 상태를 지우지 않는다. Windows 로그인/hotkey/Acrylic, Mac native, 실제 DB/서버/모델 성공은 Linux 계약 검사로 인증하지 않는다.
