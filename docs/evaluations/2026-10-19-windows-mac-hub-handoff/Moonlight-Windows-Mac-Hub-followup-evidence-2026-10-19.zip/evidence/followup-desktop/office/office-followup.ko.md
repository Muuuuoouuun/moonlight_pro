# D2: Office 확정 미수락 충돌의 입력 잠금 복구

후속 승인에 따라 기존 후보 `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`와 기존 패치/보고서를 보존하고 별도 clone `/workspace/moonlight-audit/desktop-office-followup`에서 수정했다. 검증 baseline은 후보에 기존 `desktop-generation-guard.patch`를 적용한 상태다. 이번 delta에는 그 기존 변경이 포함되지 않는다.

## 결과와 정확한 범위

서버가 현재 요청 ID를 등록하지 않았음을 증명하는 두 충돌만 보류를 해제한다. 질문·초안은 보존하며, 최신 회의를 다시 읽은 뒤 사용자가 보내기를 눌러야 새 요청을 만든다. 종료된 회의는 다시 읽은 뒤에도 읽기 전용이다.

전송 계층은 다음 조건을 모두 확인한다.

- 요청이 정확한 `/api/hub/office/meetings/<UUID>/turns` POST이며 query나 변형 경로가 없다.
- 응답 HTTP 409, JSON `status:conflict`, `persisted:false`.
- error가 `meeting-revision-changed` 또는 `meeting-closed`.
- envelope 키는 status/error/persisted/businessWrites만이며, businessWrites가 있다면 false.

조건을 만족할 때만 기계 오류 코드를 기존 4필드 IPC 봉투에 그대로 보낸다. renderer는 이 검증된 코드만 보류 해제에 사용한다. 새 봉투 필드, 서버 API, DB, 인증/보안 설정을 추가하지 않았다. UI는 기존 오류 영역의 한국어 설명을 통해 접수되지 않았고 입력은 보관했음을 알린다.

이 allowlist의 근거는 `20261007_0069_office_meetings.sql`의 claim 순서다. 같은 requestId가 있으면 먼저 반환하고, 그 뒤에 revision 변경/종료 분기가 있으므로 위 두 코드는 현재 ID가 아직 turn으로 등록되지 않았음을 뜻한다. **meeting-request-id-reused는 기존 turn을 가리킬 수 있으므로 포함하지 않는다.** `persisted:false` 단독으로도 확정 거절을 판단하지 않는다. Hub 담당자가 실제 service→HTTP 경계를 실행한 별도 계약 6검사(`evidence/followup-hub/outcome-contract.test.mjs`, `.tap`)에서도 이 조건과 finish 이후 unknown 경로를 확인했다.

일반 409, reused ID, persisted 누락/true, turn receipt와 충돌하는 봉투, timeout, 응답 유실, unknown202, server502, preview는 기존 pending ID와 입력을 유지한다. 보류 상태로 복원한 요청을 GET 결과만으로 미수락이라고 추정하거나 자동 재전송하는 로직은 추가하지 않았다. 따라서 모든 불확실 요청 복구를 해결한 패치는 아니다. 이번 확정 미수락 코드 2개 밖의 결과는 계속 보수적으로 보류한다.

## 검증

신규 `apps/desktop/pet/renderer/office-recovery.test.js`는 실제 Office renderer를 최소 DOM의 Node VM에서 실행하고, 실제 `createHubBridge → createPetHub → createHubClient`를 거쳐 주입 fetch 응답을 받는다. DOM 렌더링 실기/Electron 성공 검사가 아니라 상태 전이와 API 계약 검사다.

- 정확히 같은 신규 13검사를 별도 baseline clone `/workspace/moonlight-audit/desktop-office-followup-before`에서 실행: **10 pass / 3 fail**, exit1 (`before-final.tap`). 실패는 두 확정 충돌의 잠금 복구와 transport 분류다.
- 수정 후 신규 13검사와 Office API/transport/IPC bridge 기존 검사: **49 pass / 0 fail**, exit0 (`after-final.tap`).
- 충돌 후 POST가 자동 증가하지 않고, refresh GET 뒤에도 1회이며, 사용자의 새 send 때만 새 requestId·최신 revision으로 두 번째 POST가 나가는 것을 확인했다.
- 모호한 응답별 pending 원래 ID·입력 보존, GET 재조회 및 primary 반복에도 POST 추가 0회를 확인했다.
- `git diff --check` 및 원본 후보를 대상으로 한 `git apply --check` 통과. 원본을 수정한 것은 아니다.
- `/root/remote_refs`의 독립 소스·증거 검토에서 새 blocker 없음.

실행 명령(각 clone 루트):

```sh
node --test --test-reporter=tap apps/desktop/pet/renderer/office-recovery.test.js
node --test --test-reporter=tap apps/desktop/pet/renderer/office-recovery.test.js apps/desktop/pet/main/pet-office-api.test.js apps/desktop/pet/main/pet-hub-client.test.js apps/desktop/pet/main/pet-hub-bridge.test.js
```

`before.tap`/`after.tap`은 초기 11검사 단계의 이력이며, 최종 소스와 일치하는 수치는 `before-final.tap`/`after-final.tap`을 따른다.

## 제공 패치

- `office-definitive-rejection.patch`
- SHA256 `c871bb9381e8ce56d22bd5bcb461dbd6d88680c1263b1991e69bb026236307a8`
- 4파일, +150/-2 (신규 테스트 134줄 포함).
- 구조적 base: 후보 `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`. 기존 generation 패치와 수정 파일이 달라 순서에 의존하지 않지만, 이번 시험은 generation 적용 상태에서 수행했다.
- D3 cancellation delta와 수정 파일도 겹치지 않는다. 권장 통합 순서: 후보 → 기존 generation → 이번 D2 → 별도 D3.

Windows 실기 로그인/hotkey/Acrylic, 실제 서버/DB/모델, Mac native/compiler는 실행하지 않았다. Claude API 호출, 원격쓰기, 배포, 보안 설정 변경은 없다. 기존 후보/패치/보고서를 교체하거나 덮어쓰지 않았다.
