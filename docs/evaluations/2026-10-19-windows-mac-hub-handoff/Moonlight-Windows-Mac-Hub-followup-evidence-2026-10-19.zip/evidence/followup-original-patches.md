# 원래 세 패치의 확정 범위

기준 후보는 `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`이다. 아래는 최초 전달한 세 패치만 설명하며 후속 수정 결과를 섞지 않는다. 기존 patch·manifest·보고서는 보존했다.

| 원래 패치 | 변경 경로 | 수정 범위·전후 증거 |
|---|---|---|
| `desktop/desktop-generation-guard.patch` | `apps/desktop/pet/main/pet-hub.js` 및 신규 `apps/desktop/pet/main/pet-hub-generation.test.js` | 초기화를 기다리던 `chatSend`/`tick`의 연결 객체가 교체됐으면 전송 전에 거부한다. 신규 4개 회귀: 후보에서 4 fail, 수정 후 4 pass. 관련 선택 시험 76 pass/0 fail; 원래 세 패치 동시 적용본 Desktop 전체 376 pass/0 fail/3 skip. |
| `hub/hub-contract-retry-candidate.patch` | `apps/hub/lib/office/engine-client.js` 및 신규 `apps/hub/lib/office/engine-client-retry.test.mjs` | 이미 받은 4xx·버전/응답 계약 거부 뒤 생성 POST를 자동 반복하지 않는다. 신규 시험은 후보에서 3개 중 1 pass/2 fail(관찰 POST 2회), 수정 후 관련 18 pass/0 fail. 확장 Office 계약 216 pass/0 fail/2 skip. legacy 502/503·전송 예외 재시도는 남는다. |
| `host/native-preflight-generation.patch` | `prototypes/moonlight-pet-macos/Sources/MoonlightPetPreview/Support/HubTransport.swift` 및 `prototypes/moonlight-pet-macos/Tests/MoonlightPetPreviewTests/HubTransportTests.swift` | desktop/shared bridge preflight await 뒤 세대·Task 취소를 확인한다. 소스 흐름·적용/공백 검사 완료. 기존 Node wiring 4 pass는 Swift 실행 증거가 아니다. 신규 Swift 2개 테스트/12조합은 컴파일러 부재로 변경 전후 모두 미실행. |

정확한 SHA256:

- Desktop: `250da48139a7b1c4983766ed24bd7e1cfbbf3bc33b8d991d681d04b87ed4afcb` (3,235 bytes).
- Hub: `a6aeb9888c8273ae78b9aa40151fe8db36f7b3030f94e6eca4e11f2c3a5bfd23` (3,687 bytes).
- Swift: `75032dbd1045e6d63ebc502fec279761d249f2b524cff8c85906361140a32d31` (10,632 bytes).

각 패치는 원본 후보에 개별 `git apply --check` exit 0이다. 별도 `patched-validation`에 세 개를 함께 적용했고 충돌 없이 적용 및 `git diff --check`를 통과했다. 이 누적 적용본에서 Desktop 376 pass/3 skip, Office+native wiring 선택 190 pass/2 skip, Hub webpack build exit 0을 확인했다. **누적 적용본의 루트 전체 npm test는 재실행하지 않았다.** 원본 후보의 전체 시험 결과는 5576 pass/3 fail/34 skip이며 main에서도 같은 3 fail을 재현했다. 선택 시험은 중복되므로 합산하지 않는다.

원래 세 패치를 모두 적용한 뒤에도 다음 항목은 남는다:

- **D2 — Office 409 복구:** turn 생성 전 revision 충돌이 확정 거절됐어도 renderer pending이 남아 입력을 잠근다. timeout/unknown과 확정 미수락을 구별하는 복구는 원래 패치에 없다.
- **D3 — 준비 대기 중 Council 취소:** `chatSend`가 초기화를 기다릴 때 `chatCancel`은 `cancelled:false`이고, 같은 연결에서 준비 완료 뒤 POST 1회가 실행된다. 원래 세대 가드는 연결 교체만 막는다.
- **긴 회의 복원:** 8turn 응답 267,322 bytes가 Desktop 262,144-byte 상한을 넘어 정상 Hub 응답을 거부한다. 페이지네이션/본문 투영 계약은 원래 패치에 없다.
- **Mac 세션:** 같은 세대에서 old valid session + `signedOut:true`가 공존하는 snapshot, shell 재시작 뒤 로그아웃 의도 유실, 조건부 descriptor 교체/종료 경합은 원래 Swift preflight 패치로 해결되지 않는다.
- 영속 `running/unknown` 회의의 cancel/recover API, 서버에서 시작한 모델 작업의 실제 취소 보장, Native 첫 20개 목록 뒤 cursor 탐색도 별도 범위다.

근거: `patch-application-and-preservation.json`, `validation-summary.json`, `independent-patch-review.md`, `desktop/generation-{before,after}.tap`, `hub/retry-{before,after}.tap`, `hub/office-contract-after.tap`, 각 담당 한국어 보고서. Windows/Mac 실기·Swift 컴파일·Keychain·Acrylic/Metal 검증 결과로 해석하지 않는다.
