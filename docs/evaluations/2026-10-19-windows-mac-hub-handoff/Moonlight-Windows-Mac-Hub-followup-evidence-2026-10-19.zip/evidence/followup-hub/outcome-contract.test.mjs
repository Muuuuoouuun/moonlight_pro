import assert from 'node:assert/strict';
import { test } from 'node:test';
import { pathToFileURL } from 'node:url';
import path from 'node:path';

const root = process.env.MOONLIGHT_AUDIT_ROOT;
if (!root) throw new Error('Set MOONLIGHT_AUDIT_ROOT to the isolated repository');
const from = file => import(pathToFileURL(path.join(root, file)).href);
const { createOfficeMeetingService } = await from('apps/hub/lib/office/meeting-service.js');
const { createOfficeMeetingHandler } = await from('apps/hub/lib/office/meeting-http.js');
const { parseOfficeRequest, OFFICE_VERSION } = await from('packages/agent-contracts/office.js');
const meetingId = '11111111-1111-4111-8111-111111111111';
const requestId = '22222222-2222-4222-8222-222222222222';
const actor = { workspaceId: '33333333-3333-4333-8333-333333333333', operatorId: 'operator' };
const input = { requestId, expectedRevision: 1, message: '입력 검토', includeProjects: false };
const canonical = parseOfficeRequest({ ownerId: 'eevee', mode: 'chat', scope: 'personal', message: input.message });
const meeting = { meetingId, title: '격리 검증', scope: 'personal', ownerId: 'eevee', mode: 'chat', reviewers: [],
  revision: 2, state: 'open', decisionContext: '', sourceTask: null };
const context = { source: 'provided', scope: 'personal', projects: [], note: '입력만 사용' };
const generated = { status: 'generated', version: OFFICE_VERSION, ...canonical, answer: '응답', nextAction: '직접 확인', context };
const turn = state => ({ id: requestId, roundNumber: 1, state, request: canonical,
  result: state === 'generated' ? generated : state === 'unknown' ? { status: 'unknown', error: 'office-generation-outcome-unknown' } : null });
const detail = turns => ({ status: 'ready', persisted: true, meeting, turns, skillRequests: [] });
const http = service => createOfficeMeetingHandler('turn', { service, identity: () => actor, guard: () => null });
const send = async (service, body = input) => {
  const response = await http(service)(new Request(`https://hub.invalid/api/hub/office/meetings/${meetingId}/turns`,
    { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }),
  { params: Promise.resolve({ id: meetingId }) });
  return { status: response.status, body: await response.json() };
};

test('exact preclaim revision and closed conflicts retain code and false persistence without generation', async () => {
  for (const error of ['meeting-revision-changed', 'meeting-closed']) {
    const calls = [];
    const service = createOfficeMeetingService({ rpc: async name => {
      calls.push(name);
      if (name === 'office_meeting_get_v1') return detail([]);
      if (name === 'office_meeting_turn_claim_v1') return { status: 'conflict', error, persisted: false };
      assert.fail('unexpected storage mutation');
    }, readContext: () => assert.fail('preclaim rejection cannot read provider context'),
    generate: () => assert.fail('preclaim rejection cannot generate') });
    const response = await send(service);
    assert.equal(response.status, 409);
    assert.deepEqual(response.body, { status: 'conflict', error, persisted: false });
    assert.deepEqual(calls, ['office_meeting_get_v1', 'office_meeting_turn_claim_v1']);
  }
});

test('postgeneration finish conflicts become unknown, not a safe preclaim 409', async () => {
  for (const error of ['meeting-attempt-mismatch', 'meeting-result-already-saved']) {
    let syntheticGenerations = 0;
    const service = createOfficeMeetingService({ rpc: async name => {
      if (name === 'office_meeting_get_v1') return detail([]);
      if (name === 'office_meeting_turn_claim_v1') return { ...detail([]), claimed: true, attemptToken: 'opaque-test', turn: turn('running') };
      if (name === 'office_meeting_turn_finish_v1') return { status: 'conflict', error, persisted: false };
      assert.fail('unexpected RPC');
    }, readContext: async () => context, generate: async () => { syntheticGenerations++; return generated; } });
    const response = await send(service);
    assert.equal(syntheticGenerations, 1);
    assert.equal(response.status, 202);
    assert.equal(response.body.status, 'unknown');
    assert.equal(response.body.persisted, null);
    assert.equal(response.body.error, 'office-meeting-result-persistence-unknown');
    assert.equal(response.body.turn.result.status, 'generated');
    assert.equal(Object.hasOwn(response.body, 'attemptToken'), false);
  }
});

test('request-ID reuse conflict can coexist with a stored unknown turn', async () => {
  const stored = turn('unknown');
  const service = createOfficeMeetingService({ rpc: async name => {
    if (name === 'office_meeting_get_v1') return detail([stored]);
    if (name === 'office_meeting_turn_claim_v1') return { status: 'conflict', error: 'meeting-request-id-reused', persisted: false };
    assert.fail('reuse conflict must not generate or finish');
  }, readContext: () => assert.fail('provider context forbidden'), generate: () => assert.fail('provider forbidden') });
  const response = await send(service, { ...input, expectedRevision: 2 });
  assert.equal(response.status, 409);
  assert.equal(response.body.error, 'meeting-request-id-reused');
  assert.equal(response.body.persisted, false);
  assert.equal((await service.get(meetingId, actor)).turns[0].state, 'unknown');
});

test('finish conflict followed by a persisted generated reread returns the actual saved turn', async () => {
  let reads = 0;
  const service = createOfficeMeetingService({ rpc: async name => {
    if (name === 'office_meeting_get_v1') return detail(reads++ ? [turn('generated')] : []);
    if (name === 'office_meeting_turn_claim_v1') return { ...detail([]), claimed: true, attemptToken: 'opaque-test', turn: turn('running') };
    return { status: 'conflict', error: 'meeting-result-already-saved', persisted: false };
  }, readContext: async () => context, generate: async () => generated });
  const response = await send(service);
  assert.equal(response.status, 200);
  assert.equal(response.body.status, 'generated');
  assert.equal(response.body.persisted, true);
  assert.equal(response.body.turn.id, requestId);
});

test('a persisted unknown replay stays unknown and does not call the provider', async () => {
  let claims = 0;
  const stored = turn('unknown');
  const service = createOfficeMeetingService({ rpc: async name => {
    if (name === 'office_meeting_get_v1') return detail([stored]);
    if (name === 'office_meeting_turn_claim_v1') { claims++; return { ...detail([stored]), claimed: false, turn: stored }; }
    assert.fail('unknown must not be finished again');
  }, readContext: () => assert.fail('unknown cannot be re-generated'), generate: () => assert.fail('provider forbidden') });
  for (let i = 0; i < 2; i++) {
    const response = await send(service);
    assert.equal(response.status, 202); assert.equal(response.body.status, 'unknown');
    assert.equal(response.body.persisted, true); assert.equal(response.body.turn.id, requestId);
  }
  assert.equal(claims, 2);
});

test('the handler error persistence flag alone does not prove a request was never executed', async () => {
  let serviceEntered = false;
  const response = await send({ turn: async () => { serviceEntered = true; throw new Error('after unspecified service effects'); } });
  assert.equal(serviceEntered, true);
  assert.equal(response.status, 502); assert.equal(response.body.persisted, false);
});
