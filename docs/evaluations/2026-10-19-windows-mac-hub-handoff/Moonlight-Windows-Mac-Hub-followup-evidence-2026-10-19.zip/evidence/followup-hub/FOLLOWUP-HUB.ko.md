# Hub 후속 검증 — 확정 거절·긴 회의·unknown 복구

기준 후보 `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`를 새 독립 복제본 `/workspace/moonlight-audit/followup-hub-audit`에서 점검했다. 기존 후보와 이전 세 패치는 보존했다. 이번 Hub 후속에서는 **새 소스 패치를 만들지 않았다.** Desktop 담당의 안전한 409 복구 수정에 필요한 계약을 제공했고, 긴 회의는 원문·보호 한도를 함께 지키는 좁은 수정이 없어 후속 설계로 남긴다.

## Desktop에 전달한 안전한 409 조건

대상은 정확히 `POST /api/hub/office/meetings/{id}/turns`다. 현재 서버 코드에서 다음 조합만 신규 전송의 요청 ID 미등록을 증명한다.

```text
HTTP 409
status === "conflict"
persisted === false
error ∈ {"meeting-revision-changed", "meeting-closed"}
```

SQL `20261007_0069_office_meetings.sql:154–157`은 기존 request ID를 먼저 검사한다. 따라서 그 뒤 `:159–160`에서 반환되는 위 두 오류는 turn insert 전의 확정 거절이고 해당 ID의 기존 turn도 없다. 정확한 경로·메서드·응답 조합을 별도 marker로 전달하는 Desktop 수정이 적합하다. HTTP 409 전체를 일괄 해제하거나 `persisted:false`만 믿으면 안 된다.

| 응답/오류 | 해석 |
|---|---|
| `meeting-revision-changed`, `meeting-closed` | 위 조합이면 해당 신규 ID의 turn 미등록. 초안을 보존하고 최신 회의를 읽은 뒤 사용자가 다시 판단할 수 있음 |
| `meeting-request-id-reused` | 다른 본문/회의/소속으로 **해당 ID가 실제 존재**함. `expectedRevision`만 바꾼 재전송도 본문 해시 충돌을 낼 수 있음. 기존 unknown이 함께 있을 수 있어 자동 해제 allowlist에서 제외 |
| `meeting-attempt-mismatch`, `meeting-result-already-saved` | finish RPC가 생성 후 반환할 수 있는 충돌. `persisted:false`라도 생성 전 거절이 아님 |
| handler 일반 502 + `persisted:false` | 서비스 진입 후 예외일 수 있으므로 미실행 증거가 아님 |

현재 `meeting-service.js:142–148`은 finish 충돌을 그대로 HTTP 409로 전달하지 않는다. 저장 결과를 다시 읽어 완료 turn이 있으면 실제 완료를 반환하고, 그렇지 않으면 HTTP 202 `unknown`, `persisted:null`을 반환한다. 미래 서버 변경을 고려해서도 오류 코드 allowlist는 넓히지 않는 편이 적절하다.

`outcome-contract.test.mjs`는 실제 service와 HTTP handler를 쓰고 RPC·생성 부분만 메모리 주입했다. **6 pass / 0 fail**이다. 외부 DB·실제 provider 호출은 0회다.

- 정확한 preclaim 두 오류: 409 코드 보존, 컨텍스트/생성 호출 없음.
- 생성 후 두 finish 충돌: 202 unknown, 생성된 응답은 미확인으로 보존.
- finish 충돌 후 저장 완료 재조회: 200 generated, persisted true.
- `request-id-reused` 409·persisted false와 기존 unknown turn 공존.
- 동일 ID의 persisted unknown 재조회/재전송: 계속 unknown, 생성 없음.
- handler 일반 예외의 persisted false만으로 미실행을 증명할 수 없음.

## 긴 회의: 좁은 패치를 보류하는 구체적 이유

원래 세 패치 적용 전과 적용 후(`/workspace/moonlight-audit/patched-validation`)에 같은 문제를 재현했다. 7 turn은 233,947 bytes로 Desktop에서 읽고, 8 turn은 Hub가 HTTP 200 ready를 반환해도 267,322 bytes여서 Desktop의 262,144-byte 보호 한도에 걸린다. 각 질문 1,000자·답변 10,000자는 현재 실제 서버 parser의 정상 범위다.

이 문제는 불필요한 메타데이터만 제거하는 변경으로 해결되지 않는다. 한글 질문·답변 원문만 합쳐도 다음 크기다.

```text
8 × (1,000 + 10,000) × 3 UTF-8 bytes = 264,000 bytes
264,000 − 262,144 = 1,856 bytes 초과
```

JSON 필드·ID·상태를 전부 빼도 이미 한도를 초과한다. 근거는 `minimum-text-bound.json`이다.

검토한 작은 변경과 보류 이유:

- 상한 삭제/증대: 기존 보호 한도를 완화하고 다음 크기의 정상 회의에서 다시 실패한다. 요청 범위에 맞지 않는다.
- 숨은 과거 turn 삭제 또는 본문 자르기: 완전한 저장 대화 복원 계약을 바꾸고, 대화 원문·사용자가 찾는 turn·미확인 turn을 숨길 수 있다.
- 불필요한 history/context 투영: 전송량 일부는 줄지만 위 필수 원문 하한 때문에 일반 해결이 아니다.
- client 내부에서만 배열 분할: 전체 JSON은 이미 transport가 읽고 어댑터 한도에서 거절되므로 네트워크 계약을 바꾸지 않고는 해결되지 않는다.

안전한 후속 구현에는 서버 turn 페이지네이션 또는 제한된 투영과 cursor 계약, Desktop/Native/Hub의 페이지 합치기·중복/순서 역전 처리, 선택 turn 복원, 미확인 turn을 빠뜨리지 않는 전송 금지 판단이 함께 필요하다. 기존 클라이언트의 기본 전체 응답을 유지할지와 새 opt-in 형식도 정해야 한다. 이 범위를 임의의 작은 패치로 출하하지 않았다.

원래 세 패치의 수정 경로는 Desktop `pet-hub.js`의 초기화 세대 가드, Hub `engine-client.js`의 결정적인 응답 뒤 재시도, Native `HubTransport.swift`의 preflight 가드다. **어느 것도** Desktop `pet-office-api.js:76–79`의 전체 응답 한도나 SQL `office_meeting_get_v1`의 전체 turn 반환을 바꾸지 않는다. 그러므로 세 패치를 모두 적용한 뒤에도 다음 조건이 남는다.

- meeting/create/send/detail이 돌려준 전체 JSON이 262,144 bytes를 넘으면 Desktop은 `invalid-response`를 반환한다.
- `meetingDetail`의 1,000 turn 상한도 그대로다. 서버 GET에는 이에 대응하는 turn 페이지가 없다.
- 재조회 역시 같은 큰 응답이면 계속 실패한다.

적용 전 증거는 이 폴더의 `compatibility-probes.{mjs,json,log}`, 원래 세 패치 누적 적용본의 증거는 `original-three-patches/compatibility-probes.{mjs,json,log}`에 분리 보존했다. 기존 최초 증거 파일은 덮어쓰지 않았다.

## terminal unknown 복구 계약 — 코드 변경 없음

현재 unknown은 두 상황을 구분해서 읽어야 한다.

1. **저장 행은 running, deadline을 넘긴 공개 표시는 unknown.** SQL `office_meeting_turn_public_v1:65`의 투영이다. 아직 result hash가 없으면 원래 attempt token으로 늦게 도착한 finish가 완료 상태를 저장할 수 있다. GET 재조회가 이후 성공을 발견할 수 있다.
2. **finish가 status unknown을 실제 저장했고 result hash가 존재.** 같은 요청 ID 재시도는 기존 turn을 돌려주며 새 생성은 하지 않는다. 다른 결과로 finish하려 하면 `meeting-result-already-saved`이고, 새 request ID도 기존 unknown 때문에 `meeting-turn-unresolved`로 막힌다. 단순 polling이 이를 자동으로 완료시키지는 않는다.

회의 경로에는 사용자가 unknown을 확정 실패로 바꾸거나 재개하는 cancel/recover API가 없다. `/office/requests/{id}/recover`는 별도 workflow receipt 계약이며 meeting turn의 복구 엔드포인트가 아니다. 임의로 unknown을 error로 바꾸거나 새 ID를 자동 발급하면 실제 생성 여부가 불명인 요청을 다시 생성할 수 있어 이번 작업에서 하지 않았다. 새 회의에서의 명시적인 새 요청도 기존 요청 결과를 복구한 것으로 표현할 수 없다.

클라이언트 취소는 이미 시작한 서버/모델 작업의 실제 중단을 보장하지 않는다. 이 경로의 end-to-end 취소·취소 receipt 계약은 여전히 별도다.

## 환경·보존·한계

- 새 복제본 HEAD는 기준 후보와 같고 tracked 변경은 없다.
- lock 설치본의 node_modules를 새 복제본 안에 복사했으며 workspace 링크는 새 복제본의 소스로 향한다. Node 24.19.0, Next 16.3.8을 사용했다.
- 실제 DB·Claude/API·모델·배포된 Hub 호출은 하지 않았다. 네트워크를 사용하는 생성은 전부 메모리 대체다.
- 기존 패치 3개·원본 후보는 보존했다. 이번 결과는 새 후속 증거이며 이전 보고서/manifest를 갱신하지 않았다.
- Windows/Mac 실기, 로그인, hotkey, Acrylic/Metal, Swift/native 실행 증거가 아니다.
- 원격쓰기/PR/main병합/배포/삭제/보안설정변경/거절 우회는 없었다. 승인 대기·거절·불확실한 원격 실행 결과는 없다.

재실행:

```sh
cd /workspace/moonlight-audit/followup-hub-audit
MOONLIGHT_AUDIT_ROOT="$PWD" node --import ./scripts/register-hub-alias.mjs --test /workspace/moonlight-audit/evidence/followup-hub/outcome-contract.test.mjs
MOONLIGHT_AUDIT_ROOT="$PWD" node --import ./scripts/register-hub-alias.mjs /workspace/moonlight-audit/evidence/followup-hub/compatibility-probes.mjs
```
