import assert from 'node:assert/strict';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { writeFile } from 'node:fs/promises';

const root = process.env.MOONLIGHT_AUDIT_ROOT;
if (!root) throw new Error('Set MOONLIGHT_AUDIT_ROOT to the isolated candidate checkout');
const moduleAt = relative => import(pathToFileURL(path.join(root, relative)).href);
const require = createRequire(path.join(root, 'package.json'));
const { createOfficeApi, meetingDetail } = require('./apps/desktop/pet/main/pet-office-api.js');
const { createOfficeMeetingHandler } = await moduleAt('apps/hub/lib/office/meeting-http.js');
const { parseOfficeRequest, parseOfficeAnswer, OFFICE_VERSION } = await moduleAt('packages/agent-contracts/office.js');
const id = '11111111-1111-4111-8111-111111111111';
const meeting = { meetingId: id, scope: 'personal', title: '격리 계약 검증', ownerId: 'eevee', reviewers: [], mode: 'chat',
  revision: 9, state: 'open', createdAt: '2026-10-19T00:00:00Z', updatedAt: '2026-10-19T01:00:00Z' };
const request = parseOfficeRequest({ ownerId: 'eevee', scope: 'personal', mode: 'chat', message: '문'.repeat(1000) });
const result = { status: 'generated', version: OFFICE_VERSION, ownerId: 'eevee', scope: 'personal', mode: 'chat',
  ...parseOfficeAnswer({ answer: '답'.repeat(10000), nextAction: '직접 검토' }, 'chat') };
const turn = i => ({ id: `22222222-2222-4222-8222-${String(i + 1).padStart(12, '0')}`, roundNumber: i + 1,
  state: 'generated', request, result });
const details = count => ({ status: 'ready', persisted: true, meeting, turns: Array.from({ length: count }, (_, i) => turn(i)), skillRequests: [] });
async function throughHttp(count) {
  const handler = createOfficeMeetingHandler('get', { identity: () => ({ workspaceId: id, operatorId: 'operator' }),
    service: { get: async () => details(count) } });
  const response = await handler(new Request(`https://hub.invalid/api/hub/office/meetings/${id}`), { params: Promise.resolve({ id }) });
  const json = await response.json();
  return { httpStatus: response.status, json, status: json.status, source: json.source, preview: false };
}
const seven = await throughHttp(7), eight = await throughHttp(8);
assert.equal(meetingDetail(eight.json, id, 'personal').turns.length, 8);
assert.equal((await createOfficeApi({ request: async () => seven }).detail({ id, scope: 'personal' })).turns.length, 7);
let rejection;
try { await createOfficeApi({ request: async () => eight }).detail({ id, scope: 'personal' }); }
catch (error) { rejection = { kind: error.kind, error: error.error }; }
assert.deepEqual(rejection, { kind: 'invalid', error: 'invalid-response' });
const report = { base: '67eb1d9b316843f5acd70de513d5a7b8d823bfdc', synthetic: true, externalNetworkCalls: 0,
  validRequestCharacters: request.message.length, validAnswerCharacters: result.answer.length,
  sevenTurns: { bytes: Buffer.byteLength(JSON.stringify(seven.json)), desktop: 'accepted' },
  eightTurns: { bytes: Buffer.byteLength(JSON.stringify(eight.json)), hubHttp: eight.httpStatus, hubStatus: eight.json.status, desktop: rejection },
  note: 'Hub route accepts valid records but Desktop whole-envelope byte bound prevents opening the 8-turn meeting. No real database or provider was used.' };
await writeFile(new URL('./compatibility-probes.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
