# 후속 패치 독립 검토

기준 후보 `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`. 작성자와 별개로 최종 소스·patch·회귀 코드·저장된 전후 로그를 읽었다. 이 검토에서는 제품 코드를 수정하거나 시험을 재실행하지 않았고, 원격 조회/쓰기·Claude 호출·운영 서비스/DB·네이티브 빌드를 실행하지 않았다. 기존 최초 세 패치와 보고서는 보존했다.

판정: 아래 최종 후속 세 패치의 명시된 범위에서 새 차단 결함은 발견하지 못했다. 최초 세 패치의 효과와 후속 패치의 효과를 혼합하면 안 된다. 후속 패치를 모두 합친 시험은 통합 담당자의 별도 누적 검증으로 확인해야 한다.

## D2 — Office 확정 거절 복구

검토 파일: `followup-desktop/office/office-definitive-rejection.patch`.
SHA256: `c871bb9381e8ce56d22bd5bcb461dbd6d88680c1263b1991e69bb026236307a8`.

`pet-hub-client.js`는 정확한 Office turn POST 경로, HTTP 409, `status:conflict`, `persisted:false`, `meeting-revision-changed`/`meeting-closed` 두 코드, 허용 필드만 있는 응답을 요구한다. 실제 SQL은 기존 request ID를 먼저 확인하고 두 오류를 insert 전에 반환한다. `publicDetail`·`turnResponse`·HTTP handler를 거친 실제 응답도 이 형태를 유지한다. 따라서 이 두 오류만 renderer pending에서 해제하는 것은 타당하다. request ID 재사용·추가 receipt·모순 persistence·unknown·timeout·offline은 해제하지 않는다.

초안을 보존하고 GET 새로고침 및 명시적인 새 send를 요구한다. 자동 생성 재시도는 추가하지 않는다. closed 회의는 읽기 전용을 유지한다. `office-recovery.test.js`는 실제 renderer→`createHubBridge`→`createPetHub`→transport를 연결하고 fetch만 주입해 동작을 검사한다. `before-final.tap` 13개 중 10 pass/3 fail, `after-final.tap` 관련 49 pass/0 fail 증거를 확인했다. 원본 후보에 독립 적용 가능한 패치이며 최초 generation 패치를 중복 포함하지 않는다.

## D3 — 준비 중 Council 취소

검토 파일: `followup-desktop/cancellation/desktop-queued-cancellation.patch`.
SHA256: `a466754719e967b0386fe9f3e99a37471dbe4088275d649c1ac9b117d98caa7d`.

`pet-hub.js`의 `chatRequest`가 초기화 대기부터 응답까지 단일 요청을 점유한다. 취소는 준비 단계 점유를 해제하고 기존 `chat.cancel()`도 항상 호출한다. await 뒤 ticket 확인과 소유자가 맞을 때만 수행하는 상태 갱신/finally 정리가 늦은 이전 요청이 새 요청을 해제하는 경합을 막는다. connect/dispose에서 무효화하며 연결 교체는 기존 `stale-origin`, 같은 연결의 명시 취소는 `cancelled`로 구분한다.

회귀는 준비 중 POST 0회, 반복 취소·명시 새 전송, 중복 차단, 늦은 이전 응답, origin/세션 교체, dispose 및 기존 abort 동작을 관측한다. 원본+최초 generation 패치에서 신규 8개 중 4 pass/4 fail, 변경 후 관련 61 pass, 전체 Desktop 384 pass/3 skip을 확인했다.

이 patch는 **candidate67 → 최초 `desktop-generation-guard.patch`(SHA256 `250da48139a7b1c4983766ed24bd7e1cfbbf3bc33b8d991d681d04b87ed4afcb`) → D3 delta** 순서가 필요하다. 서버에서 시작한 모델 작업의 취소·롤백은 보장하지 않는다. 준비 중 점유는 `chatSession().busy`에 노출되지 않고, 취소된 이전 Promise는 준비 I/O가 끝날 때까지 남을 수 있으나 새 전송 점유를 막지 않는다.

## Mac bridge — snapshot 일관성

검토 파일: `followup-session/session-snapshot-consistency.patch`.
SHA256: `f1464d693def09901a94594aa867c1d87bd30c6ded170b3d0825a4638d9960c8`.

`hub-session-bridge.js`가 명시 signedOut을 session:null보다 우선시하며, cookie 이벤트/쓰기 전후 revision으로 지연된 read를 한 번만 다시 읽는다. 계속 바뀌면 기존 rejected 봉투를 사용한다. 최초 후속 초안에서는 cookies.set 대기 중 같은 revision의 old cookie를 다시 읽을 수 있음을 독립 검토에서 지적했다. 최종판은 origin별 pending-write refcount, snapshot 조회 전후 pending 거부, 성공/실패 공통 finally 해제 및 revision 증가로 이 구간을 닫았다. 겹친 쓰기 중 한 작업만 끝나도 나머지 점유를 보존한다.

실제 UNIX socket + 메모리 cookie 대역 회귀에 held-set 전/도중 read, 겹친 쓰기, 실패 후 정상 read 복구가 추가됐다. 최종 신규 8개는 후보에서 1 pass/7 fail, 변경 후 8 pass이며 관련 기존 Mac 전용 3개는 skip이다. 최종 8개판 전체 Desktop 재실행은 383 total/380 pass/0 fail/3 skip(`desktop-suite.tap`)이다. 이 판정은 Electron cookie 이벤트·Swift·Keychain의 실제 동작 검증이 아니다.

이 수정은 snapshot의 모순과 경합을 제한한다. shell 재시작 뒤 signedOut tombstone 보존, 모든 concurrent write의 직렬화, Swift fallback 및 native end-to-end 정책, descriptor 교체/종료 경합을 해결했다고 볼 수 없다. 기존 권한·소켓 경로·인증 정책을 완화하지 않는다.

## Hub 후속 — 새 패치 없음

`followup-hub/FOLLOWUP-HUB.ko.md`, `minimum-text-bound.json`, `outcome-contract.tap`을 검토했다. 질문 1,000자와 답변 10,000자인 한글 8turn은 필수 원문만 264,000 bytes여서 262,144-byte 상한을 넘는다. JSON 메타데이터 제거만으로 해결할 수 없고 원문/미확인 turn을 숨기는 절단이나 보호 한도 확대는 적절한 일반 해결이 아니다. 공통 페이지네이션·원문 조회·pending receipt 조회 계약 설계가 필요하므로 작은 Hub 패치 보류는 근거가 있다.

실제 service+HTTP handler 경계 시험 6 pass는 preclaim 확정 거절, 생성 후 finish 충돌/unknown, 저장 완료 재조회, ID 재사용과 terminal unknown을 구분한다. 전체 unknown을 error로 바꾸거나 새 ID를 자동 발급하는 수정은 없다. 긴 회의·terminal unknown 복구/취소 API·native cursor 공백은 남는다.

이 문서의 선택 시험 수는 겹치므로 합산하지 않는다. Windows/Mac 실기 hotkey/login/Acrylic/Metal 및 Swift 컴파일은 검증 범위 밖이다. 최종 적용·검증은 각각의 SHA256과 명시한 dependency를 기준으로 해야 한다.
