# 검토용 패치 적용·검증

기준 commit: `67eb1d9b316843f5acd70de513d5a7b8d823bfdc`.
원본 후보를 보존한 별도 로컬 checkout에서 사용한다. 원격 쓰기·운영 DB·모델·Claude API 호출 없이 진행한 검증 기록이다.

1. 전달 ZIP의 `FILE-SHA256.tsv` 및 `PATCH-MANIFEST.json`을 확인한다.
2. 정확한 기준 commit의 clean checkout에서 `git apply --check /path/to/patches/all-six-candidate.patch`를 실행한다.
3. 동일한 patch를 적용한다. 이 방식에서는 개별 패치를 다시 적용하지 않는다.
4. 개별 적용을 선택하면 순서는 다음과 같다. D3는 O1 이후의 delta이므로 O1이 선행해야 한다.

```text
O1 desktop-generation-guard.patch
O2 hub-contract-retry-candidate.patch
O3 native-preflight-generation.patch
D2 office-definitive-rejection.patch
D3 desktop-queued-cancellation.patch
S2 session-snapshot-consistency.patch
```

`git diff --check`, `npm --workspace @com-moon/desktop test`, `npm run lint`를 격리 환경에서 수행했다. lockfile 의존성은 기존 독립 검증의 `npm ci --ignore-scripts --no-audit --no-fund` 결과를 사용했다. 환경은 Linux/Node24.19.0/npm11.9.0이다. Desktop 405 pass/0 fail/3 skip, syntax guard1780files/0issues가 최종 누적 결과다.

루트 전체 시험 및 웹 빌드는 후속 Desktop 수정 뒤 반복하지 않았다. 이전 원본 후보 전체는 5576 pass/3 기존 main fail/34 skip이다. 원래 세 패치 누적 Hub build는 통과했다. Swift 컴파일·native 실행은 검증하지 않았다. `source-only/`는 테스트 파일을 제외한 검토용 동일 코드이므로 전체 패치와 중복 적용하지 않는다.

증거 ZIP의 `previous/`에는 원래 보고서와 원래 증거 ZIP이 그대로 들어 있다. 후속 증거는 `evidence/`다. runtime 임시 파일을 보존하며, 운영 `.env`·인증정보·DB를 가져오지 않는다. 실제 외부 서비스 호출이 필요한 절차는 이 문서에 없다.
